/**************************************************************************//**
  \file
    tcMem.h
  \brief
    Security Trust Centre memory manager header file.
  \internal
    Copyright (c)Meshnetics.
    History:
      2007.12.25 - ALuzhetsky created.
******************************************************************************/
#ifndef _TCMEM_H
#define _TCMEM_H

/******************************************************************************
                              Includes section.
******************************************************************************/
#include "queue.h"
#include "tcTaskManager.h"
#include "tcAuthenticHandler.h"
#include "tcKeyUpdateHandler.h"
#include "tcKeyEstablishHandler.h"
#include "tcRemoveHandler.h"

/******************************************************************************
                        Types section.
******************************************************************************/
/**************************************************************************//**
  \brief TBD.

  TBD
******************************************************************************/
typedef struct PACK
{
  TcTaskManagerMem_t         taskManagerMem;
  TcAuthenticHandlerMem_t    authenticHandlerMem;
  TcKeyUpdateHandlerMem_t    keyUpdateHandlerMem;
#ifdef _HIGH_SECURITY_
  TcKeyEstablishHandlerMem_t keyEstablishHandlerMem;
#endif // _HIGH_SECURITY_
  TcRemoveHandlerMem_t       removeHandlerMem;
} TcMem_t;

/******************************************************************************
                        External variables.
******************************************************************************/
extern TcMem_t tcMem;

/******************************************************************************
                        Inline functions prototypes section.
******************************************************************************/
/**************************************************************************//**
  \brief TBD.
  
  \param TBD.
  \return TBD.
******************************************************************************/
INLINE TcTaskManagerMem_t* tcGetTaskManagerMem(void)
{
  return &tcMem.taskManagerMem;
}

/**************************************************************************//**
  \brief TBD.
  
  \param TBD.
  \return TBD.
******************************************************************************/
INLINE TcAuthenticHandlerMem_t* tcGetAuthenticHandlerMem(void)
{
  return &tcMem.authenticHandlerMem;
}

/**************************************************************************//**
  \brief TBD.
  
  \param TBD.
  \return TBD.
******************************************************************************/
INLINE TcKeyUpdateHandlerMem_t* tcGetKeyUpdateHandlerMem(void)
{
  return &tcMem.keyUpdateHandlerMem;
}

/**************************************************************************//**
  \brief TBD.
  
  \param TBD.
  \return TBD.
******************************************************************************/
#ifdef _HIGH_SECURITY_
INLINE TcKeyEstablishHandlerMem_t* tcGetKeyEstablishHandlerMem(void)
{
  return &tcMem.keyEstablishHandlerMem;
}
#endif // _HIGH_SECURITY_

/**************************************************************************//**
  \brief TBD.
  
  \param TBD.
  \return TBD.
******************************************************************************/
INLINE TcRemoveHandlerMem_t* tcGetRemoveHandlerMem(void)
{
  return &tcMem.removeHandlerMem;
}

#endif //_TCMEM_H

// eof tcMem.h
