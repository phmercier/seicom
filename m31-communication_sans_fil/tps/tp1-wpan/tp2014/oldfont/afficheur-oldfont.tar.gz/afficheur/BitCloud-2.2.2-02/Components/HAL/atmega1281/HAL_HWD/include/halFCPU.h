#define F_CPU 4000000
