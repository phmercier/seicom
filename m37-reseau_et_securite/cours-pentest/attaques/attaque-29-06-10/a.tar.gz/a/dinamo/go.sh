./ss 22 -b $1 -i eth0 -s 6
cat bios.txt |sort | uniq > mfu.txt
./ssh-scan
rm -f bios.txt
